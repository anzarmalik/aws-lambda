import time 

def hello(event, context):
    print("hi")
    print("I am Developer")
    time.sleep(4)
    return "Dev"
